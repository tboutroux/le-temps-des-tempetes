# meteo-react-native
A project using react native

How to use:

Run the command : npm install

Run the command: expo start --web
