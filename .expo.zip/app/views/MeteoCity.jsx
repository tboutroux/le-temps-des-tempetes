import * as React from 'react' // Permet d'utiliser JSX
import { useEffect } from 'react' // Permet d'utiliser useEffect
import { View, Text, StyleSheet, FlatList } from 'react-native' // Permet d'utiliser des composants React Native
import Api from '../models/Api' // Permet d'utiliser la classe Api
import weatherCode from '../services/weatherCode' // Permet d'utiliser le tableau weatherCode

const MeteoCity = ({ navigation, route }) => {
  // On récupère la navigation et les paramètres de la route
  const meteoAPI = new Api()

  // On initialise les variables d'état
  const [meteoCityFor5Days, setMeteoCityFor5Days] = React.useState({})
  //Objet factice pour eviter les erreurs dans le code
  const [meteoCity, setMeteoCity] = React.useState({
    city: { name: '' },
    forecast: [
      [],
      [],
      [],
      [
        {
          cp: 93170,
          datetime: '2022-03-01T19:00:00+0100',
          day: 0,
          dirwind10m: 113,
          gust10m: 22,
          gustx: 22,
          insee: '93006',
          latitude: 48.8691,
          longitude: 2.4227,
          period: 3,
          probafog: 0,
          probafrost: 10,
          probarain: 20,
          probawind70: 0,
          probawind100: 0,
          rr1: 0,
          rr10: 0,
          temp2m: 10,
          weather: 5,
          wind10m: 5,
        },
      ],
    ],
  })

  // On initialise la variable d'état loading à true
  const [loading, setLoading] = React.useState(true)

  // On utilise useEffect pour charger les données de l'API
  useEffect(() => {
    getMeteoForCity(route.params.insee)
    getMeteoForCity5days(route.params.insee)
  }, [])

  // On utilise une fonction asynchrone pour récupérer les données de l'API
  const getMeteoForCity = async (insee) => {
    const result = await meteoAPI.getMeteoForCityForNextHour(insee)
    setMeteoCity(result)
    setLoading(false)
  }

  // On utilise une fonction asynchrone pour récupérer les données de l'API
  const getMeteoForCity5days = async (insee) => {
    const result = await meteoAPI.getMeteoForCityFor5Days(insee)
    setMeteoCityFor5Days(result)
  }

  // On utilise une fonction pour formater la date
  const dateFormat = (dateISO) => {
    const date = new Date(dateISO)
    const dateFormat =
      date.getDate() + '-' + (date.getMonth() + 1) + '-' + date.getFullYear() //prints expected format.

    return dateFormat
  }

  // On utilise une fonction pour afficher les prévisions
  const renderItem = ({ item }) => (
    // On utilise la fonction dateFormat pour afficher la date
    <View style={styles.previsionView} key={item.datetime}>
      <Text style={styles.previsionTitle}>{dateFormat(item.datetime)}</Text>
      <Text>{weatherCode[item.weather]}</Text>
      <Text>
        T°Max : {item.tmax} T°Min : {item.tmin}
      </Text>
      <Text>
        Rafale de vent à 10 mètres : {item.wind10m}
        {' km/h '}
      </Text>
    </View>
  )

  
  return (
    <>
      {!loading && (
        <>
          <View style={styles.weatherContainer}>
            <View style={styles.headerContainer}>
              <Text style={styles.tempText}>
                {meteoCity.city.name} {meteoCity.forecast[0][3].temp2m}˚
              </Text>
              <Text style={styles.subtitle}>
                {weatherCode[meteoCity.forecast[0][3].weather]}
              </Text>
            </View>
            <View style={styles.weatherContainer}>
              <FlatList
                data={meteoCityFor5Days}
                renderItem={renderItem}
                keyExtractor={(item) => item.id}
              />
            </View>
          </View>
        </>
      )}
    </>
  )
}

// On utilise une variable pour le style
const styles = StyleSheet.create({
  weatherContainer: {
    flex: 1,
    backgroundColor: '#add8e6',
  },
  headerContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tempText: {
    fontSize: 48,
    color: '#fff',
  },
  bodyContainer: {
    flex: 2,
    alignItems: 'flex-start',
    justifyContent: 'flex-end',
    paddingLeft: 25,
    marginBottom: 40,
  },
  title: {
    fontSize: 48,
    color: '#fff',
  },
  subtitle: {
    fontSize: 24,
    color: '#fff',
  },
  previsionView: {
    backgroundColor: '#98D7DC',
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  previsionTitle: {
    fontSize: 20,
    marginBottom: 3,
  },
})

// On exporte la fonction MeteoCity
export default MeteoCity
